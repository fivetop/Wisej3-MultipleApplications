﻿
using System;
using Wisej.Web;

namespace Wisej.MultipleApplications
{
	public partial class Default : Page
	{
		public Default()
		{
			InitializeComponent();
		}
	}
}
