﻿
using System;
using Wisej.Web;

namespace Wisej.MultipleApplications
{
	public partial class Page3 : Page
	{
		public Page3()
		{
			InitializeComponent();
		}
	}
}
