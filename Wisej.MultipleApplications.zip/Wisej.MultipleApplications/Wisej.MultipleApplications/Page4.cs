﻿
using System;
using Wisej.Web;

namespace Wisej.MultipleApplications
{
	public partial class Page4 : Page
	{
		public Page4()
		{
			InitializeComponent();
		}
	}
}
