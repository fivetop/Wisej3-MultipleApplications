﻿
using System;
using Wisej.Web;

namespace Wisej.MultipleApplications
{
	public partial class Page1 : Page
	{
		public Page1()
		{
			InitializeComponent();
		}
	}
}
