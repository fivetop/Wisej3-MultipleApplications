﻿
using System;
using Wisej.Web;

namespace Wisej.MultipleApplications
{
	public partial class Page2 : Page
	{
		public Page2()
		{
			InitializeComponent();
		}
	}
}
